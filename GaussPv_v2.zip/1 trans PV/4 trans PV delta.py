import numpy as np
from CosmoFunc import *
from GaussPv import *
#------------------------------------------------------------------------------










Data_type        = 'Mock'#
out_Vsamp        = False
deltadj          = 1.0001  #   10   #
deltatyp         = 'PvMin'   #   'PvR'    #






input_dir_mock   = '/Users/fei/WSP/Scie/Proj6/Data/Orig/CF4TFmocks/CF4TF_mock'
output_dir_Vsamp = '/Users/fei/WSP/Scie/Proj6/Data/Prod/Vsamp/CF4_Vsamp'+str(deltadj)
output_dir_mock  = '/Users/fei/WSP/Scie/Proj6/Data/Prod/GaussPv/CF4mock_bc'+str(deltadj)









#=============================      Main Code      ============================
NVp_Sp=285310
N_spls=3000
print(Data_type,deltadj)
if(Data_type=='Mock'):
 Omega_M= 0.3121  ;  Omega_A= 1.0-Omega_M  ;  Hubl   = 100.
 Imock=5 #255
 Jmock=8   
 Nmock=Jmock*Imock
 for i_mock in range(Imock):
  i_mock=i_mock+19000 +  5*3
  for j_mock in range(Jmock):
    print('mock:',str(i_mock)+'.'+str(j_mock))
    input_dir = input_dir_mock+str(i_mock)+'.'+str(j_mock)
    infilm= np.loadtxt(input_dir)
    outdir= output_dir_mock+str(i_mock)+'.'+str(j_mock)
    ID    = infilm[:,0]
    RA    = infilm[:,1]
    DEC   = infilm[:,2]
    cz    = infilm[:,3];z=cz/LightSpeed
    logdt = infilm[:,4]
    logd  = infilm[:,5]
    elogd = infilm[:,6]
    Vpec  = Vpec_Fun(cz/LightSpeed,logd,Omega_M,Omega_A, Hubl)
    Ngal  = len(RA) 
    if(out_Vsamp):
        out_Vsamp_dir = output_dir_Vsamp+'mock_bc'+str(i_mock)+'.'+str(j_mock)
    else:
        out_Vsamp_dir = np.nan
    Vp_new, eVp_new,Lambd, Delta ,breakFlags= Vp_BCsamp(NVp_Sp,N_spls,deltadj,deltatyp,z,logd,elogd,Omega_M,Omega_A, Hubl,out_Vsamp,out_Vsamp_dir)

    outfile = open(outdir, 'w')
    outfile.write("#ra      dec     cz     logd     elogd     Vpec_bc     eVpec_bc    bc_nv      bc_d     flag\n")
    for i in range(Ngal):
        outfile.write("%12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %3d\n" % (RA[i],DEC[i],cz[i],logd[i],elogd[i],Vp_new[i],eVp_new[i],Lambd[i], Delta[i],breakFlags[i]))
    outfile.close()
    
    
