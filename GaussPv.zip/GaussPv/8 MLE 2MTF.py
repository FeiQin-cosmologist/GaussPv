#==========================================================================
#
#                              INTRODUCTION
#
#--------------------------------------------------------------------------


# python /Users/fei/WSP/Scie/Proj5/Prog/Part2/1\ 2MTF/7\ BQ\ wMLE\ 2MTF.py

# Take the FAKE Cosmic3 surveys and calculate the true Bulk flow for each patch



import math
import numpy as np
from scipy.linalg import lapack
from CosmoFunc import *
import matplotlib.pyplot as plt
from BF_OptMC  import *
from chainconsumer import ChainConsumer
from astropy import units as u
from astropy.coordinates import SkyCoord
#==========================================================================
#
#                                  CODE
#
#--------------------------------------------------------------------------
# 1. INITIAL SETTING:





Fit_tech='qMLE'
nfiles  = 8
Do_lb   = True

input_dir_2MTF ='/Users/fei/WSP/Scie/Proj5/Data/Prod/GaussPv/2MTF_bc'
 

 






#=================================      MLE   =================================
# read in the true bulk flow which is known from similations:
print(Fit_tech)
# 2. MLE:--
OmegaM = 0.312;  OmegaA = 1.0- OmegaM;  Hub    = 100.0#70.5  
infile=np.loadtxt(input_dir_2MTF)
ra_2mtf      = infile[:,0] ; dec_2mtf      = infile[:,1] ; z_2mtf = infile[:,2]/LightSpeed
logd_2mtf    = infile[:,3] ; elogd_2mtf    = infile[:,4]  
Vpec_bc_2mtf = infile[:,5] ; eVpec_bc_2mtf = infile[:,6]
nv_2mtf      = infile[:,7] ; delt_2mtf     = infile[:,8]
if(Do_lb):
    c = SkyCoord(ra=ra_2mtf, dec=dec_2mtf, unit=(u.degree, u.degree))
    x = c.galactic
    l = np.asarray( x.l)
    b = np.asarray(x.b)
    ra_2mtf  = l   
    dec_2mtf = b
# opt and mcmc:
if(Fit_tech=='qMLE' ):    
    B_opt,Sv_opt                    = Opt_qMLE(ra_2mtf,dec_2mtf,Vpec_bc_2mtf,eVpec_bc_2mtf,nv_2mtf,delt_2mtf)        
    B_MC ,Sv_MC, Um_Cov,SX,SY,SZ,SS = MC_qMLE( ra_2mtf,dec_2mtf,Vpec_bc_2mtf,eVpec_bc_2mtf,nv_2mtf,delt_2mtf)
if(Fit_tech=='etaMLE' ):    
    B_opt,Sv_opt                    = Opt_etaMLE(ra_2mtf,dec_2mtf,z_2mtf,logd_2mtf,elogd_2mtf,OmegaM,OmegaA,Hub) 
    B_MC ,Sv_MC, Um_Cov,SX,SY,SZ,SS = MC_etaMLE( ra_2mtf,dec_2mtf,z_2mtf,logd_2mtf,elogd_2mtf,OmegaM,OmegaA,Hub) 
if(Fit_tech=='wMLE' ): 
    Vpec_2mtf = Vpec_Fun_wat(z_2mtf,logd_2mtf,OmegaM,OmegaA, Hub)
    eVpec_2mtf= Vpec_Fun_wat(z_2mtf,elogd_2mtf,OmegaM,OmegaA, Hub)
    B_opt,Sv_opt                    = Opt_wMLE(ra_2mtf,dec_2mtf,Vpec_2mtf,eVpec_2mtf)        
    B_MC ,Sv_MC, Um_Cov,SX,SY,SZ,SS = MC_wMLE( ra_2mtf,dec_2mtf,Vpec_2mtf,eVpec_2mtf)
if(Fit_tech=='tMLE' ): 
    Vpec_2mtf = Vpec_Fun_tra(z_2mtf,logd_2mtf,OmegaM,OmegaA, Hub) 
    eVpec_2mtf= 0.177*z_2mtf*LightSpeed
    B_opt,Sv_opt                    = Opt_tMLE(ra_2mtf,dec_2mtf,Vpec_2mtf,eVpec_2mtf)        
    B_MC ,Sv_MC, Um_Cov,SX,SY,SZ,SS = MC_tMLE( ra_2mtf,dec_2mtf,Vpec_2mtf,eVpec_2mtf)
# error of BKF:
eB,elong,elat=BK_error(B_opt,Um_Cov)
jing=np.arctan(SY/SX)*180.0/math.pi
wei=np.arcsin(SZ/np.sqrt(SX**2+ SY**2+ SZ**2))*180.0/math.pi
meanjing=np.mean(jing)
meanwei=np.mean(wei)
ndata=len(jing)
err_jing=np.sqrt(  np.sum(  (jing-meanjing)*(jing-meanjing)    )/(ndata-1)  )
err_wei=np.sqrt(  np.sum(  (wei-meanwei)*(wei-meanwei)    )/(ndata-1)  )

# output:
print('=============     ',Fit_tech,'     =============')
if(Do_lb):print('Galactic')
if(not Do_lb):print('Equotral')
print('Optimization----:','\n         |B|=',np.linalg.norm(B_opt),'\n         [Bx,By,Bz]=',B_opt,'\n         SigV=',Sv_opt)  
print('MCMC------------:','\n         |B|=',np.linalg.norm(B_MC) ,'\n         [Bx,By,Bz]=',B_MC ,'\n         SigV=',Sv_MC)       
print('MCMC direction--:','\n             ',meanjing,meanwei)
print('error_MCMC------:','\n         ',np.std(np.sqrt(SX**2+ SY**2+ SZ**2)),   np.sqrt(Um_Cov.diagonal()),   err_jing,   err_wei) 
print('error_Jacb------:','\n         ',eB                                  ,   np.sqrt(Um_Cov.diagonal()),   elong   ,   elat   ) 

# MCMC plots: 
data=np.asarray(  [SX,SY,SZ]  );data=data.T
mean=B_MC
c = ChainConsumer().add_chain(data, parameters=["$B_x$","$B_y$","$B_z$"]) 
c.configure(flip=False,  colors="#00bfa5",tick_font_size=16,label_font_size=16, cloud=True, sigma2d=True, sigmas=[1,1.5,2,2.5])
fig = c.plotter.plot(figsize=(6, 6),filename='/Users/fei/WSP/Scie/Proj5/Results/MCMC_2MTF_'+Fit_tech+'.png' ,truth=mean)
plt.show()
    









    
