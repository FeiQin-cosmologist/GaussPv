import numpy as np
import matplotlib.pyplot as plt
import scipy as sp 
from scipy import stats
from GaussPv import *
 




     

input_dir_Vsamp = '/Users/fei/WSP/Scie/Proj5/Data/Prod/Vsamp/2MTF_Vsamp_yj.npy'
input_dir       = '/Users/fei/WSP/Scie/Proj5/Data/Prod/GaussPv/2MTF_yj'

input_2MTF      = '/Users/fei/WSP/Scie/Proj5/Data/Orig/2MTF_pkin_clipped 2.dat'



# 1. read data:----------------------------------------------------------------
infile=np.loadtxt(input_2MTF) 
cz   = infile[:,2]  
logd = infile[:,3]  
elogd= infile[:,4]

Vp_new   = np.loadtxt(input_dir)[:,3]
lbd      = np.loadtxt(input_dir)[:,5]
Ngal     = len(Vp_new)
CDF_v,Vp_sp,Vp_sp_yj = np.load(input_dir_Vsamp, allow_pickle=True)
# 2. distribution:-----------------------
i_gal=5

# watkins P(v)
eta=np.linspace(-1.0,1.0,400)
Peta=P_eta(eta,logd[i_gal],elogd[i_gal])
OmegaM = 0.3121
Hub    = 100.0#70.5
OmegaA = 1.0- OmegaM
deccel = 3.0*OmegaM/2.0 - 1.0
z    = cz[i_gal]/LightSpeed
Vmod = cz[i_gal]*(1.0 + 0.5*(1.0 - deccel)*z - (2.0 - deccel - 3.0*deccel*deccel)*z*z/6.0)
Pv_wat=Peta*(  (1.0+Vmod/LightSpeed)/(math.log(10)*Vmod)     )
Vpec_wat =  Vpec_Fun_wat(z,eta,OmegaM,OmegaA, Hub)


# plots:--------------------- 
plt.figure(1,figsize=(8,6))
plt.hist(Vp_sp[i_gal,:],70,density=True,label='distribution of PV',alpha=0.5);
x=np.linspace(np.min(Vp_sp[i_gal,:]),5*np.max(Vp_sp[i_gal,:]),150);   
y=sp.stats.norm.pdf(x,np.mean(Vp_sp[i_gal,:]),np.std(Vp_sp[i_gal,:]))
plt.plot(x,y,color='tomato',label='Gaussian curve',linewidth=2.5)
plt.plot(Vpec_wat,Pv_wat,ls='-.',color='g',label='$P(v^{wat}_p)$',linewidth=2.5)
plt.xlim(-1100,2250)
plt.legend(fontsize=15)
plt.ylabel('density',fontsize=22);
plt.xlabel('$V_p~[ km~s^{-1}]$',fontsize=18);  
plt.xticks(fontsize=15);  
plt.yticks(fontsize=15); 
plt.grid(True)

plt.figure(2,figsize=(8.95,6))
plt.hist(Vp_sp_yj[i_gal,:],70,density=True,label='distribution of PV',alpha=0.5);
x=np.linspace(-800,3300,150);   
y=sp.stats.norm.pdf(x,np.mean(Vp_sp_yj[i_gal,:]),np.std(Vp_sp_yj[i_gal,:]))
plt.plot(x,y,color='tomato',label='Gaussian curve',linewidth=3)
plt.xlim(-700,3000)
plt.legend(fontsize=15)
plt.ylabel('density',fontsize=22);
plt.xlabel('$Y$',fontsize=18);  
plt.xticks(fontsize=15);  
plt.yticks(fontsize=15); 
plt.grid(True)


# 3. L(lambda ):---------------------------------------------------------------
x = Vp_sp[i_gal,:]

xlw= -0.7
xup= 2.5
Nps= 80
lbs,lpdf=PDF_YJ_lambda(x,xlw,xup, Nps)
print('should equal:', lbs[lpdf==np.max(lpdf)],'=',lbd[i_gal])
plt.figure(3,figsize=(8,6))
yup=1.01*np.max(lpdf)
ylw=np.min(lpdf)

plt.plot(lbs,lpdf/10**5, c='lime')
plt.scatter(lbs,lpdf/10**5, c='lime')
plt.plot( [lbs[lpdf==np.max(lpdf)],lbs[lpdf==np.max(lpdf)]],[0.7*ylw/10**5,0.7*yup/10**5],'--',color='goldenrod',linewidth=2.5  )
plt.text(0.6,1.8*yup/10**5 , '$\lambda=%1.3f$' % lbs[lpdf==np.max(lpdf)],fontsize=22,c='goldenrod')
plt.xlim(-0.,2)
plt.ylim(0.7*ylw/10**5,0.7*yup/10**5)
plt.xlabel('$\lambda$',fontsize=22);
plt.ylabel('$L(\lambda)~[~10^{5}~]$',fontsize=22);  
plt.xticks(fontsize=16);  
plt.yticks(fontsize=16); 
plt.grid(True)



# 4. Vp_new vs. mean()Vsamp:---------------------------------------------------
test_mean = np.zeros(Ngal)
for igal in range(Ngal):
    test_mean[igal] = np.mean(Vp_sp_yj[igal,:])
plt.figure(4)
plt.scatter(Vp_new,test_mean,c='r')
plt.plot(   Vp_new,Vp_new,color='k')
plt.xlabel('V_p(trans)',fontsize=22);
plt.ylabel('V_p(mean)',fontsize=22);  


# 5. llf()lbs vs. lbd:---------------------------------------------------------
lbd_llf=np.zeros(len(lbd))
for i_gal in range(Ngal): 
    x = Vp_sp[i_gal,:]
    xlw= 0.9
    xup= 2.7
    Nps= 50
    lbs,lpdf=PDF_YJ_lambda(x,xlw,xup, Nps)
    lbd_llf[i_gal]=lbs[lpdf==np.max(lpdf)] 
plt.figure(5)
plt.scatter(lbd,lbd_llf,c='r')
plt.plot( lbd,lbd,color='k')
plt.xlabel('$\lambda$',fontsize=22);
plt.ylabel('$\lambda$(llf)',fontsize=22);  



# 6:---------------------------------------------------------------------------
infile=np.loadtxt(input_2MTF) 
cz   = infile[:,2]  
logd = infile[:,3]  
elogd= infile[:,4]
Omega_M=0.3121
Omega_A=1.0-Omega_M
Hubl   = 100.
Vpec = Vpec_Fun(cz/LightSpeed,logd,Omega_M,Omega_A, Hubl)
plt.figure(6)
plt.scatter(logd,lbd,c='r')
plt.xlabel('$\eta$',fontsize=22);
plt.ylabel('$\lambda$',fontsize=22);    


plt.show()