import numpy as np
import matplotlib.pyplot as plt
import scipy as sp 
from scipy import stats
from GaussPv import *
from CosmoFunc import * 




     

input_dir_Vsamp = '/Users/fei/WSP/Scie/Proj5/Data/Prod/Vsamp/2MTF_Vsamp_bc.npy'
input_dir       = '/Users/fei/WSP/Scie/Proj5/Data/Prod/GaussPv/2MTF_bc'

 

# 1. read data:----------------------------------------------------------------
infile   =np.loadtxt(input_dir)
ra       =infile[:,0]
dec      =infile[:,1]
cz       =infile[:,2]
logd     =infile[:,3]
elogd    =infile[:,4]
Vp_bc    =infile[:,5]
eVp_bc   =infile[:,6]
lbd      =infile[:,7]
delt     =infile[:,8]
Ngal=len(ra)
CDF_v,Vp_sp,Vp_sp_bc = np.load(input_dir_Vsamp, allow_pickle=True)
# 2. distribution:-----------------------
i_gal=4

# watkins P(v)
eta=np.linspace(-1.0,1.0,400)
Peta=P_eta(eta,logd[i_gal],elogd[i_gal])
OmegaM = 0.307
Hub    = 100.0#70.5
OmegaA = 1.0- OmegaM
deccel = 3.0*OmegaM/2.0 - 1.0
z    = cz[i_gal]/LightSpeed
Vmod = cz[i_gal]*(1.0 + 0.5*(1.0 - deccel)*z - (2.0 - deccel - 3.0*deccel*deccel)*z*z/6.0)
Pv_wat=Peta*(  (1.0+Vmod/LightSpeed)/(math.log(10)*Vmod)     )
Vpec_wat =  Vpec_Fun_wat(z,eta,OmegaM,OmegaA, Hub)
spl_z2d=spline_Rsf2Dis(OmegaM,OmegaA,Hub, 10000, 1.)
spl_d2z=spline_Dis2Rsf(OmegaM,OmegaA,Hub, 10000, 1.)
# traditional P(v)
Vpec_wat_test =  Vpec_Fun_wat(cz/LightSpeed,logd,OmegaM,OmegaA, Hub)
Vpec_test = Vpec_Fun(cz/LightSpeed,logd,OmegaM,OmegaA, Hub)
Pvp,Vp,Norm=PDFv(eta,z,logd[i_gal],elogd[i_gal],OmegaM,OmegaA, Hub,spl_z2d,spl_d2z)


# plots:--------------------- 
ind=np.where(Pvp>=(0.1*np.max(Pvp)))
ds=np.abs(    Vp[Pvp==np.max(Pvp)]  -  Vp[Pvp==np.min(Pvp[ind])]   )
cuts=Vp[ind[0][0]]
xcts=[Vp[ind[0][0]],Vp[Pvp==np.max(Pvp)] ]
ycts=[Pvp[ind[0][0]],Pvp[ind[0][0]]]
plt.figure(1,figsize=(9,6))
plt.hist(Vp_sp[i_gal,:],70,density=True,label='distribution of $v_i$',alpha=0.6);
x=np.linspace(np.min(Vp_sp[i_gal,:]),5*np.max(Vp_sp[i_gal,:]),350);
y=sp.stats.norm.pdf(x,np.mean(Vp_sp[i_gal,:]),np.std(Vp_sp[i_gal,:]))
plt.plot(x,y,color='tomato',label='Gaussian curve',linewidth=3)
#plt.plot(Vpec_wat,Pv_wat,ls='-.',color='g',label='$P(v^{wat}_p)$',linewidth=2.5)
plt.plot(Vp,Pvp,ls='-.',color='g',label='$P_{spl}(V)$',linewidth=1.5)
plt.arrow(-293.1950957398479,0.0001407662274068281,198.1950957398479+531.15008724,0.,width=0.000005,head_width=0.0001,head_length=100, fc='gold', ec='gold')
plt.arrow(0,0.0001407662274068281,531.15008724-(203.1950957398479+531.15008724),0.,width=0.000005,head_width=0.0001,head_length=100, fc='gold', ec='gold')
plt.text(100, 0.14*np.max(Pvp) , '$r$' ,fontsize=25,c='gold')
plt.plot([xcts[0] ,xcts[0]  ],[0,0.2*np.max(Pvp)],ycts,ls='-.',color='gold',linewidth=2.5)
plt.plot([Vp[Pvp==np.max(Pvp)] ,Vp[Pvp==np.max(Pvp)] ],[0,np.max(Pvp)],ycts,ls='-.',color='gold',linewidth=2.5)
plt.xlim(-1000,1850)
plt.legend(fontsize=15)
plt.ylabel('density',fontsize=22);
plt.xlabel('$V~[ km~s^{-1}]$',fontsize=18);
plt.xticks(fontsize=15);
plt.yticks(fontsize=15);
#plt.grid(True)
plt.title(  '2MASX09582105+3222119',fontsize=16)
plt.savefig("/Users/fei/WSP/Scie/Proj5/Results/Pv.pdf", dpi=150, bbox_inches='tight')



plt.figure(2,figsize=(8,6))
ind=np.argsort(Vp_sp[i_gal,:])
plt.plot(CDF_v[i_gal,ind],Vp_sp[i_gal,ind],linewidth=3.5,label='$v=f_{spl}(CDF)$');
x=np.linspace(0,1,50); 
y=np.interp(x,CDF_v[i_gal,ind],Vp_sp[i_gal,ind])
plt.scatter(x,y,c='k',label='Interpolation points $q$')
x=np.linspace(np.min(Vp_sp[i_gal,:]),np.max(Vp_sp[i_gal,:]),40); 
y=np.interp(x,Vp_sp[i_gal,ind],CDF_v[i_gal,ind])
plt.scatter(y,x,c='k')
plt.xlim(-0.01,1.01)
plt.ylim(-1000,1400)
plt.legend(fontsize=15)
plt.ylabel('$v~[ km~s^{-1}]$',fontsize=22);
plt.xlabel('$CDF$',fontsize=18);  
plt.xticks(fontsize=15);  
plt.yticks(fontsize=15); 
#plt.grid(True)
plt.title(  '2MASX09582105+3222119',fontsize=16)
plt.savefig("/Users/fei/WSP/Scie/Proj5/Results/CDFvi.pdf", dpi=150, bbox_inches='tight') 


plt.figure(3,figsize=(8.95,6))
plt.hist(Vp_sp_bc[i_gal,:],70,density=True,color='y',label='distribution of $Y_i$',alpha=0.5);
x=np.linspace(-0.6*10**(15),4.6*10**(15),150);
y=sp.stats.norm.pdf(x,np.mean(Vp_sp_bc[i_gal,:]),np.std(Vp_sp_bc[i_gal,:]))
plt.plot(x,y,color='tomato',label='Gaussian curve',linewidth=3)
plt.plot([np.mean(Vp_sp_bc[i_gal,:]),np.mean(Vp_sp_bc[i_gal,:])],[0,8.5*10**(-16)],color='b',ls='-.',linewidth=3)
plt.xlim(-0.5*10**(15),4.5*10**(15))
plt.ylim(0.,8.5*10**(-16) )
plt.text(-0.1*10**(15), 1.08*np.max(y) , '$<Y_i>=$1.967X$10^{15}$' ,fontsize=19,c='b')
plt.legend(fontsize=15)
plt.ylabel('density',fontsize=22);
plt.xlabel('$Y$',fontsize=18);
plt.xticks(fontsize=15);
plt.yticks(fontsize=15);
#plt.grid(True)
plt.title(  '2MASX09582105+3222119',fontsize=16)
plt.savefig("/Users/fei/WSP/Scie/Proj5/Results/BCY.pdf", dpi=150, bbox_inches='tight')

# 3. L(lambda ):---------------------------------------------------------------
x   = Vp_sp[i_gal,:]
x_ds= delt[i_gal]
xlw= 2
xup= 6.8
Nps= 500
lbs,lpdf=PDF_BC_lambda(x,x_ds,xlw,xup, Nps)
print('should equal:', lbs[lpdf==np.max(lpdf)],'=',lbd[i_gal])
plt.figure(4,figsize=(8,6))
yup=1.01*np.max(lpdf)
ylw=np.min(lpdf)
plt.plot(lbs,lpdf/100000., c='fuchsia')
#plt.scatter(lbs,lpdf/100000., c='fuchsia')
plt.plot( [lbs[lpdf==np.max(lpdf)],lbs[lpdf==np.max(lpdf)]],[-8.68,-8.64],'--',color='goldenrod',linewidth=2.5  )
plt.text(4.5,-8.647, '$\lambda=%1.3f$' % lbs[lpdf==np.max(lpdf)],fontsize=23,c='goldenrod')
plt.xlim(xlw,xup)
plt.ylim(-8.68,-8.64)
plt.xlabel('$\lambda$',fontsize=22);
plt.ylabel('$L(\lambda)~[~X10^{5}~]$',fontsize=22);
plt.xticks(fontsize=16);
plt.yticks(fontsize=16);
#plt.grid(True)
plt.title(  '2MASX09582105+3222119',fontsize=15)
plt.savefig("/Users/fei/WSP/Scie/Proj5/Results/BClambda.pdf", dpi=150, bbox_inches='tight')


# 4. Vp_new vs. mean()Vsamp:---------------------------------------------------
test_mean = np.zeros(Ngal)
for igal in range(Ngal):
    test_mean[igal] = np.mean(Vp_sp_bc[igal,:])
plt.figure(5,figsize=(8,6))
plt.scatter(np.log10(Vp_bc),np.log10(test_mean),s=5,c='r')
plt.plot(   [ np.min(np.log10(Vp_bc)),np.max(np.log10(Vp_bc))   ],  [ np.min(np.log10(Vp_bc)),np.max(np.log10(Vp_bc))  ]  ,color='k',ls='-.')
plt.xlabel('$log_{10}(Y)$',fontsize=22);
plt.ylabel('$log_{10}(mean(Y_i))$',fontsize=22);  
plt.xlim(np.min(np.log10(Vp_bc)),np.max(np.log10(Vp_bc)))
plt.ylim(np.min(np.log10(Vp_bc)),np.max(np.log10(Vp_bc)))
plt.xticks(fontsize=16);  
plt.yticks(fontsize=16); 
plt.grid(True)
plt.title(  '2MASX09582105+3222119',fontsize=15)
plt.savefig("/Users/fei/WSP/Scie/Proj5/Results/YmeanY.pdf", dpi=150, bbox_inches='tight') 



'''
# 5 llf()lbs vs. lbd:----------------------------------------------------------
lbd_llf=np.zeros(len(lbd))
for i_gal in range(Ngal): 
    x   = Vp_sp[i_gal,:]
    x_ds= delt[i_gal]
    xlw= 1
    xup= 9
    Nps= 100
    lbs,lpdf=PDF_BC_lambda(x,x_ds,xlw,xup, Nps)
    lbd_llf[i_gal]=lbs[lpdf==np.max(lpdf)] 
plt.figure(6)
plt.scatter(lbd,lbd_llf,c='r')
plt.plot( lbd,lbd,color='k')
plt.xlabel('$\lambda$',fontsize=22);
plt.ylabel('$\lambda$(llf)',fontsize=22);  

'''


# 6:---------------------------------------------------------------------------
Omega_M=0.307
Omega_A=1.0-Omega_M
Hubl   = 100.
dz   = DRcon(cz/LightSpeed,'z2d',Omega_M,Omega_A,Hubl)
dh   = dz*10.0**(-logd)



plt.figure(7)
plt.scatter(elogd,lbd,c='r')
plt.xlabel('$\eta$',fontsize=22);
plt.ylabel('$\lambda$',fontsize=22);


plt.show()
