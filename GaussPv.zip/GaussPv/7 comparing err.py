#==========================================================================
#
#                              INTRODUCTION
#
#--------------------------------------------------------------------------


# python /Users/fei/WSP/Scie/Proj5/Prog/Part2/1\ 2MTF/7\ BQ\ wMLE\ 2MTF.py

# Take the FAKE Cosmic3 surveys and calculate the true Bulk flow for each patch



import math
import numpy as np

from CosmoFunc import *
import matplotlib.pyplot as plt

#==========================================================================
#
#                                  CODE
#
#--------------------------------------------------------------------------
# 1. INITIAL SETTING:





Fit_tech='etaMLE' 
nfiles  = 8


input_dir_mock ='/Users/fei/WSP/Scie/Proj5/Data/Prod/GaussPv/2MTFmock_bc'
input_dir_true ='/Users/fei/WSP/Scie/Proj5/Data/Prod/2MTF-mock-trueBQ.txt'

input_dir='/Users/fei/WSP/Scie/Proj5/Data/Prod/2MTFmock_BKF'






#==========================================================================

infile = np.loadtxt(input_dir+'qMLE.txt')
Bx_qMLE   =  infile[:,0]
By_qMLE   =  infile[:,1]
Bz_qMLE   =  infile[:,2]
eBx_qMLE  =  infile[:,3]
eBy_qMLE  =  infile[:,4]
eBz_qMLE  =  infile[:,5]
SigvO_qMLE=  infile[:,6]
SigvM_qMLE=  infile[:,7]

infile = np.loadtxt(input_dir+'etaMLE.txt')
Bx_etaMLE   =  infile[:,0]
By_etaMLE   =  infile[:,1]
Bz_etaMLE   =  infile[:,2]
eBx_etaMLE  =  infile[:,3]
eBy_etaMLE  =  infile[:,4]
eBz_etaMLE  =  infile[:,5]
SigvO_etaMLE=  infile[:,6]
SigvM_etaMLE=  infile[:,7]

infile = np.loadtxt(input_dir+'wMLE.txt')
Bx_wMLE   =  infile[:,0]
By_wMLE   =  infile[:,1]
Bz_wMLE   =  infile[:,2]
eBx_wMLE  =  infile[:,3]
eBy_wMLE  =  infile[:,4]
eBz_wMLE  =  infile[:,5]
SigvO_wMLE=  infile[:,6]
SigvM_wMLE=  infile[:,7]

infile = np.loadtxt(input_dir+'tMLE.txt')
Bx_tMLE   =  infile[:,0]
By_tMLE   =  infile[:,1]
Bz_tMLE   =  infile[:,2]
eBx_tMLE  =  infile[:,3]
eBy_tMLE  =  infile[:,4]
eBz_tMLE  =  infile[:,5]
SigvO_tMLE=  infile[:,6]
SigvM_tMLE=  infile[:,7]




#==========================================================================

Cut_plt=37#43
plt.figure(1,figsize=(8,8))
ax=plt.subplot(211)
plt.scatter(eBx_qMLE,eBx_etaMLE,s=20,marker="o",c='royalblue',label='$e_{B_x}$')
plt.scatter(eBy_qMLE,eBy_etaMLE,s=20,marker="D",c='g',label='$e_{B_y}$')
plt.scatter(eBz_qMLE,eBz_etaMLE,s=80,marker="*",c='crimson',label='$e_{B_z}$')
plt.plot([20,Cut_plt],[20,Cut_plt],c='k',ls='-.')
plt.ylabel('$e_{B}(\eta MLE)$',fontsize=22)
#plt.xlabel('$e_{B}$',fontsize=22)
plt.setp(ax.get_xticklabels(), visible=False)  
plt.xlim(20,Cut_plt)
plt.ylim(20,Cut_plt)
#plt.legend(fontsize=20)
plt.xticks(fontsize=16);  
plt.yticks(fontsize=16); 
plt.grid(True)
ax=plt.subplot(212)
plt.scatter(eBx_qMLE,eBx_wMLE,s=20,marker="o",c='royalblue',label='$e_{B_x}$')
plt.scatter(eBy_qMLE,eBy_wMLE,s=20,marker="D",c='g',label='$e_{B_y}$')
plt.scatter(eBz_qMLE,eBz_wMLE,s=80,marker="*",c='crimson',label='$e_{B_z}$')
plt.plot([20,Cut_plt],[20,Cut_plt],c='k',ls='-.')
plt.ylabel('$e_{B}(wMLE)$',fontsize=22)
#plt.xlabel('$e_{B}$',fontsize=22)
#plt.setp(ax.get_xticklabels(), visible=False)  
#plt.xlim(20,Cut_plt)
#plt.ylim(20,Cut_plt)
#plt.legend(fontsize=20)
#plt.xticks(fontsize=16);  
#plt.yticks(fontsize=16); 
#plt.grid(True)
#ax=plt.subplot(313)
#plt.scatter(eBx_qMLE,eBx_tMLE,s=20,marker="o",c='royalblue',label='$e_{B_x}$')
#plt.scatter(eBy_qMLE,eBy_tMLE,s=20,marker="D",c='g',label='$e_{B_y}$')
#plt.scatter(eBz_qMLE,eBz_tMLE,s=80,marker="*",c='crimson',label='$e_{B_z}$')
#plt.plot([20,Cut_plt],[20,Cut_plt],c='k',ls='-.')
#plt.ylabel('$e_{B}(tMLE)$',fontsize=22)
plt.xlabel('$e_{B}$',fontsize=22)
plt.xlim(20,Cut_plt)
plt.ylim(20,Cut_plt)
plt.legend(fontsize=20)
plt.xticks(fontsize=16);  
plt.yticks(fontsize=16); 
plt.grid(True)
plt.subplots_adjust(left=0.125,bottom=0.1, right=0.9, top=0.9, wspace=0.2, hspace=0.02)
plt.savefig("/Users/fei/WSP/Scie/Proj5/Results/compareerrB.pdf", dpi=150, bbox_inches='tight') 


#==========================================================================


plt.figure(2,figsize=(8,12))
ax=plt.subplot(311)
plt.scatter(Bx_qMLE,Bx_etaMLE,s=20,marker="o",c='royalblue',label='$e_{B_x}$')
plt.scatter(By_qMLE,By_etaMLE,s=20,marker="D",c='g',label='$e_{B_y}$')
plt.scatter(Bz_qMLE,Bz_etaMLE,s=80,marker="*",c='crimson',label='$e_{B_z}$')
plt.ylabel('$B(\eta MLE)$',fontsize=22)
plt.setp(ax.get_xticklabels(), visible=False)  
plt.plot([-400, 400], [-400, 400],c='k',ls='-.')
plt.xlim(-400,400)
plt.ylim(-400,400)
#plt.legend(fontsize=20)
plt.xticks(fontsize=16);  
plt.yticks(fontsize=16); 
plt.grid(True)
ax=plt.subplot(312)
plt.scatter(Bx_qMLE,Bx_wMLE,s=20,marker="o",c='royalblue',label='$e_{B_x}$')
plt.scatter(By_qMLE,By_wMLE,s=20,marker="D",c='g',label='$e_{B_y}$')
plt.scatter(Bz_qMLE,Bz_wMLE,s=80,marker="*",c='crimson',label='$e_{B_z}$')
plt.ylabel('$B(wMLE)$',fontsize=22)
plt.setp(ax.get_xticklabels(), visible=False)  
plt.plot([-400, 400], [-400, 400],c='k',ls='-.')
plt.xlim(-400,400)
plt.ylim(-400,400)
#plt.legend(fontsize=20)
plt.xticks(fontsize=16);  
plt.yticks(fontsize=16); 
plt.grid(True)
ax=plt.subplot(313)
plt.scatter(Bx_qMLE,Bx_tMLE,s=20,marker="o",c='royalblue',label='$e_{B_x}$')
plt.scatter(By_qMLE,By_tMLE,s=20,marker="D",c='g',label='$e_{B_y}$')
plt.scatter(Bz_qMLE,Bz_tMLE,s=80,marker="*",c='crimson',label='$e_{B_z}$')
plt.ylabel('$B(tMLE)$',fontsize=22)
plt.xlabel('$B$',fontsize=22)
plt.plot([-400, 400], [-400, 400],c='k',ls='-.')
plt.xlim(-400,400)
plt.ylim(-400,400)
plt.legend(fontsize=20)
plt.xticks(fontsize=16);  
plt.yticks(fontsize=16); 
plt.grid(True)
plt.subplots_adjust(left=0.125,bottom=0.1, right=0.9, top=0.9, wspace=0.2, hspace=0.06)
 



plt.show()
