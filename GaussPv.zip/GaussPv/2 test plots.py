import numpy as np
import matplotlib.pyplot as plt
import scipy as sp 
from scipy import stats





Data_type=  'Survey'# 'Mock'#      




#################


input_dir_Vsamp = '/Users/fei/WSP/Scie/Proj5/Data/Prod/Vsamp/2MTF_Vsamp'
input_dir       = '/Users/fei/WSP/Scie/Proj5/Data/Prod/GaussPv/2MTF_bc'
input_dir_mock  = '/Users/fei/WSP/Scie/Proj5/Data/Prod/GaussPv/2MTFmock_bc'
 
print(Data_type)





# 1: Real surveys:-------------------------------------------------------------
if(Data_type=='Survey'):
    x   = np.loadtxt(input_dir)[:,3]
    Ngal     = len(x)
    CDF_v,Vp_sp,Vp_sp_bc = np.load(input_dir_Vsamp+'_bc.npy'   , allow_pickle=True)
# 2: Mock surveys:-------------------------------------------------------------
if(Data_type=='Mock'):
    i_mock   = 6
    print(i_mock)
    x   = np.loadtxt(input_dir_mock+str(i_mock))[:,3]
    Ngal     = len(x)
    CDF_v,Vp_sp,Vp_sp_bc = np.load(input_dir_Vsamp+'mock_bc'+str(i_mock)+'.npy', allow_pickle=True)
# 3: plots:--------------------------------------------------------------------
for i in range(10):
    i=i+1843
    plt.figure(i)
    plt.hist(Vp_sp[i,:],60,density=True);

plt.figure(30)
for i in range(Ngal):
    plt.scatter(Vp_sp[i,:],CDF_v[i,:])
 
for i in range(10):
    i=i+1843
    plt.figure(i+80)
    plt.hist(Vp_sp_bc[i,:],60,density=True);
    x=np.linspace(np.min(Vp_sp_bc[i,:]),np.max(Vp_sp_bc[i,:]),50);
    y=sp.stats.norm.pdf(x,np.mean(Vp_sp_bc[i,:]),np.std(Vp_sp_bc[i,:]))
    plt.plot(x,y)
    plt.ylim(0,1.2*np.max(y))



###############################################################################
'''




input_dir_Vsamp = '/Users/fei/WSP/Scie/Proj5/Data/Prod/Vsamp/2MTF_Vsamp_yj'
input_dir       = '/Users/fei/WSP/Scie/Proj5/Data/Prod/GaussPv/2MTF_yj'
input_dir_mock  = '/Users/fei/WSP/Scie/Proj5/Data/Orig/2MTF Mock/'
input_dir_mock  = '/Users/fei/WSP/Scie/Proj5/Data/Prod/GaussPv/2MTFmock_yj.'
 
 
# 1: Real surveys:-------------------------------------------------------------
if(Data_type=='Survey'):
    Vp_new   = np.loadtxt(input_dir)[:,3]
    Ngal     = len(Vp_new)
    CDF_v,Vp_sp,Vp_sp_yj = np.load(input_dir_Vsamp+'.npy'   , allow_pickle=True)
# 2: Mock surveys:-------------------------------------------------------------
if(Data_type=='Mock'):
    i_mock   = 3
    Vp_new   = np.loadtxt(input_dir_mock+str(i_mock))[:,3]
    Ngal     = len(Vp_new)
    CDF_v,Vp_sp,Vp_sp_yj = np.load(input_dir_Vsamp+'mock'+str(i_mock)+'.npy', allow_pickle=True)
# 3: plots:--------------------------------------------------------------------
for i in range(5):
    plt.figure(i)
    plt.hist(Vp_sp[i,:],60,density=True);

plt.figure(30)
for i in range(Ngal):
    plt.scatter(Vp_sp[i,:],CDF_v[i,:],s=0.01)
 
for i in range(5):
    plt.figure(i+80)
    plt.hist(Vp_sp_yj[i,:],60,density=True);
    x=np.linspace(np.min(Vp_sp_yj[i,:]),np.max(Vp_sp_yj[i,:]),50);   
    y=sp.stats.norm.pdf(x,np.mean(Vp_sp_yj[i,:]),np.std(Vp_sp_yj[i,:]))
    plt.plot(x,y)
    
  
    
'''    

plt.show()
