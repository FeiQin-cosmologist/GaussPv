#==========================================================================
#
#                              INTRODUCTION
#
#--------------------------------------------------------------------------


# python /Users/fei/WSP/Scie/Proj5/Prog/Part2/1\ 2MTF/7\ BQ\ wMLE\ 2MTF.py

# Take the FAKE Cosmic3 surveys and calculate the true Bulk flow for each patch



import math
import numpy as np
from scipy.linalg import lapack
from CosmoFunc import *
import matplotlib.pyplot as plt
from BF_OptMC  import *
#==========================================================================
#
#                                  CODE
#
#--------------------------------------------------------------------------
# 1. INITIAL SETTING:





Fit_tech='tMLE' 
nfiles  = 8


input_dir_mock ='/Users/fei/WSP/Scie/Proj5/Data/Prod/GaussPv/2MTFmock_bc'
input_dir_true ='/Users/fei/WSP/Scie/Proj5/Data/Prod/2MTF-mock-trueBQ.txt'

output_dir='/Users/fei/WSP/Scie/Proj5/Data/Prod/2MTFmock_BKF'






#=================================      MLE   =================================
# read in the true bulk flow which is known from similations:
print(Fit_tech)
data3=np.loadtxt(input_dir_true);
Ux_true=data3[:,0];Uy_true=data3[:,1];Uz_true=data3[:,2]
# the output of optimization and MCMC
B_opt=np.zeros((3,2*nfiles))  ;  Sv_opt=np.zeros(2*nfiles)     
B_MC =np.zeros((3,2*nfiles))  ;  Sv_MC =np.zeros(2*nfiles)
# some arrays needed to calculate Chi^2 
U_data = np.empty(3*2*nfiles);U_true = np.empty(3*2*nfiles);U_cov = np.empty((2*nfiles,3,3))
# 2. MLE:------------------------------------------------------------------
for i in range(nfiles):
    print(('mock=',i))    
    # 2.1 First the GiggleZ mock:------------- 
    OmegaM = 0.273  ;  OmegaA = 1.0- OmegaM;  Hub    = 100.0#70.5  
    infile=np.loadtxt(input_dir_mock+str(i))
    ra_2mtfm      = infile[:,0] ; dec_2mtfm      = infile[:,1] ; z_2mtfm = infile[:,2]/LightSpeed
    logd_2mtfm    = infile[:,3] ; elogd_2mtfm    = infile[:,4]  
    Vpec_bc_2mtfm = infile[:,5] ; eVpec_bc_2mtfm = infile[:,6]
    nv_2mtfm      = infile[:,7] ; delt_2mtfm     = infile[:,8]
    # opt and mcmc:
    if(Fit_tech=='qMLE' ):    
        B_opt[:,i],Sv_opt[i]                    = Opt_qMLE(ra_2mtfm,dec_2mtfm,Vpec_bc_2mtfm,eVpec_bc_2mtfm,nv_2mtfm,delt_2mtfm)        
        B_MC[:,i] ,Sv_MC[i], Um_Cov,SX,SY,SZ,SS = MC_qMLE( ra_2mtfm,dec_2mtfm,Vpec_bc_2mtfm,eVpec_bc_2mtfm,nv_2mtfm,delt_2mtfm)
    if(Fit_tech=='etaMLE' ):    
        B_opt[:,i],Sv_opt[i]                    = Opt_etaMLE(ra_2mtfm,dec_2mtfm,z_2mtfm,logd_2mtfm,elogd_2mtfm,OmegaM,OmegaA,Hub) 
        B_MC[:,i] ,Sv_MC[i], Um_Cov,SX,SY,SZ,SS = MC_etaMLE( ra_2mtfm,dec_2mtfm,z_2mtfm,logd_2mtfm,elogd_2mtfm,OmegaM,OmegaA,Hub) 
    if(Fit_tech=='wMLE' ): 
        Vpec_2mtfm = Vpec_Fun_wat(z_2mtfm,logd_2mtfm,OmegaM,OmegaA, Hub)
        eVpec_2mtfm= Vpec_Fun_wat(z_2mtfm,elogd_2mtfm,OmegaM,OmegaA, Hub)
        B_opt[:,i],Sv_opt[i]                    = Opt_wMLE(ra_2mtfm,dec_2mtfm,Vpec_2mtfm,eVpec_2mtfm)        
        B_MC[:,i] ,Sv_MC[i], Um_Cov,SX,SY,SZ,SS = MC_wMLE( ra_2mtfm,dec_2mtfm,Vpec_2mtfm,eVpec_2mtfm)
    if(Fit_tech=='tMLE' ): 
        Vpec_2mtfm = Vpec_Fun_tra(z_2mtfm,logd_2mtfm,OmegaM,OmegaA, Hub) 
        eVpec_2mtfm= 0.177*z_2mtfm*LightSpeed
        B_opt[:,i],Sv_opt[i]                    = Opt_tMLE(ra_2mtfm,dec_2mtfm,Vpec_2mtfm,eVpec_2mtfm)        
        B_MC[:,i] ,Sv_MC[i], Um_Cov,SX,SY,SZ,SS = MC_tMLE( ra_2mtfm,dec_2mtfm,Vpec_2mtfm,eVpec_2mtfm)
    # stor the out put into array:
    U_cov[i] = Um_Cov
    U_true[3*i] = Ux_true[i];   U_true[3*i+1] = Uy_true[i];   U_true[3*i+2] = Uz_true[i]   
    U_data[3*i] = B_opt[0,i];   U_data[3*i+1] = B_opt[1,i];   U_data[3*i+2] = B_opt[2,i]
    # 2.2 The the Surfs mock:-----------------
    OmegaM = 0.3121   ;   OmegaA = 1.0- OmegaM   ;   Hub    = 100.0#67.51
    infile=np.loadtxt(input_dir_mock+str(i+nfiles))
    ra_2mtfm      = infile[:,0] ; dec_2mtfm      = infile[:,1] ; z_2mtfm = infile[:,2]/LightSpeed
    logd_2mtfm    = infile[:,3] ; elogd_2mtfm    = infile[:,4]  
    Vpec_bc_2mtfm = infile[:,5] ; eVpec_bc_2mtfm = infile[:,6]
    nv_2mtfm      = infile[:,7] ; delt_2mtfm     = infile[:,8]
    # opt and mcmc:    
    # opt and mcmc:
    if(Fit_tech=='qMLE' ):    
        B_opt[:,i+nfiles],Sv_opt[i+nfiles]                    = Opt_qMLE(ra_2mtfm,dec_2mtfm,Vpec_bc_2mtfm,eVpec_bc_2mtfm,nv_2mtfm,delt_2mtfm)        
        B_MC[:,i+nfiles] ,Sv_MC[i+nfiles], Um_Cov,SX,SY,SZ,SS = MC_qMLE( ra_2mtfm,dec_2mtfm,Vpec_bc_2mtfm,eVpec_bc_2mtfm,nv_2mtfm,delt_2mtfm)
    if(Fit_tech=='etaMLE' ):    
        B_opt[:,i+nfiles],Sv_opt[i+nfiles]                    = Opt_etaMLE(ra_2mtfm,dec_2mtfm,z_2mtfm,logd_2mtfm,elogd_2mtfm,OmegaM,OmegaA,Hub) 
        B_MC[:,i+nfiles] ,Sv_MC[i+nfiles], Um_Cov,SX,SY,SZ,SS = MC_etaMLE( ra_2mtfm,dec_2mtfm,z_2mtfm,logd_2mtfm,elogd_2mtfm,OmegaM,OmegaA,Hub) 
    if(Fit_tech=='wMLE' ): 
        Vpec_2mtfm = Vpec_Fun_wat(z_2mtfm,logd_2mtfm,OmegaM,OmegaA, Hub)
        eVpec_2mtfm= Vpec_Fun_wat(z_2mtfm,elogd_2mtfm,OmegaM,OmegaA, Hub)
        B_opt[:,i+nfiles],Sv_opt[i+nfiles]                    = Opt_wMLE(ra_2mtfm,dec_2mtfm,Vpec_2mtfm,eVpec_2mtfm)        
        B_MC[:,i+nfiles] ,Sv_MC[i+nfiles], Um_Cov,SX,SY,SZ,SS = MC_wMLE( ra_2mtfm,dec_2mtfm,Vpec_2mtfm,eVpec_2mtfm)
    if(Fit_tech=='tMLE' ): 
        Vpec_2mtfm = Vpec_Fun_tra(z_2mtfm,logd_2mtfm,OmegaM,OmegaA, Hub) 
        eVpec_2mtfm= 0.177*z_2mtfm*LightSpeed
        B_opt[:,i+nfiles],Sv_opt[i+nfiles]                    = Opt_tMLE(ra_2mtfm,dec_2mtfm,Vpec_2mtfm,eVpec_2mtfm)        
        B_MC[:,i+nfiles] ,Sv_MC[i+nfiles], Um_Cov,SX,SY,SZ,SS = MC_tMLE( ra_2mtfm,dec_2mtfm,Vpec_2mtfm,eVpec_2mtfm)
    # stor the out put into array:
    U_cov[i+nfiles] = Um_Cov
    U_true[3*(i+nfiles)] = Ux_true[i+nfiles] ; U_true[3*(i+nfiles)+1] = Uy_true[i+nfiles] ; U_true[3*(i+nfiles)+2] = Uz_true[i+nfiles]    
    U_data[3*(i+nfiles)] = B_opt[0,i+nfiles] ; U_data[3*(i+nfiles)+1] = B_opt[1,i+nfiles] ; U_data[3*(i+nfiles)+2] = B_opt[2,i+nfiles]
# Varify Optmization = MCMC:----------------
plt.figure(1,figsize=(9,6))
plt.scatter( B_opt[0,:],B_MC[0,:],s=50,marker="o",c='royalblue')
#plt.errorbar(B_opt[0,:],B_MC[0,:],PyerrB[0],linestyle='',color='royalblue',marker="o",label='$B_x$')
plt.scatter( B_opt[1,:],B_MC[1,:],s=50,marker="D",c='g')
#plt.errorbar(B_opt[1,:],B_MC[1,:],PyerrB[1],linestyle='',color='g',marker="D",label='$B_y$')
plt.scatter( B_opt[2,:],B_MC[2,:],s=50,marker="*",c='crimson')
#plt.errorbar(B_opt[2,:],B_MC[2,:],PyerrB[2],linestyle='',color='crimson',marker="*",label='$B_z$')
plt.plot([-400, 400], [-400, 400], ls="--", c=".3")
plt.xlim(-400,400)
plt.ylim(-400,400)
plt.xlabel('$B_{opt}~[ km~s^{-1}]$',fontsize=22);
plt.ylabel('$B_{MCMC}~[ km~s^{-1}]$',fontsize=22);  
plt.xticks(fontsize=16);  
plt.yticks(fontsize=16); 
plt.grid(True)
plt.title('Varify Optmization=MCMC-----%s'% Fit_tech,fontsize=22)
plt.show()    
#============================   THE END OF  etaMLE   ==========================




























# 3. Calculate the chi-squared---------------------------------------------
# 3.1 chi-squared of B:
Cov_all = np.zeros((3*2*nfiles,3*2*nfiles))
for i in range(2*nfiles):
    Cov_all[3*i:3*(i+1),3*i:3*(i+1)] = U_cov[i]

pivots = np.zeros(3*2*nfiles, np.intc)
identity = np.eye(3*2*nfiles)
U_cov_lu, pivots, U_cov_inv, info = lapack.dgesv(Cov_all, identity)
chi_squared = 0.0
for i in range(3*2*nfiles):
    chi_squared += (U_data[i]-U_true[i])*np.sum(U_cov_inv[i,0:]*(U_data-U_true))

print( ' ')
print( 'Python emcee BKF Chi^2=', chi_squared/(3*2*nfiles-1.0))

# erros;
PyerrB=np.zeros((3,2*nfiles))
for i in range((2*nfiles)):
    PyerrB[0,i]=np.sqrt(Cov_all[i*3,i*3])
    PyerrB[1,i]=np.sqrt(Cov_all[i*3+1,i*3+1])
    PyerrB[2,i]=np.sqrt(Cov_all[i*3+2,i*3+2])


# 4. plots:--------------------------------------------------------------------
plt.figure(2,figsize=(9,6))
plt.scatter( Ux_true,B_opt[0,:],s=20,marker="o",c='royalblue')
plt.errorbar(Ux_true,B_opt[0,:],PyerrB[0],linestyle='',color='royalblue',marker="o",label='$B_x$')
plt.scatter( Uy_true,B_opt[1,:],s=20,marker="D",c='g')
plt.errorbar(Uy_true,B_opt[1,:],PyerrB[1],linestyle='',color='g',marker="D",label='$B_y$')
plt.scatter( Uz_true,B_opt[2,:],s=80,marker="*",c='crimson')
plt.errorbar(Uz_true,B_opt[2,:],PyerrB[2],linestyle='',color='crimson',marker="*",label='$B_z$')
plt.plot([-400, 400], [-400, 400], ls="--", c=".3")
plt.xlim(-400,400)
plt.ylim(-400,400)
plt.legend(fontsize=20)
plt.ylabel('$B( '+Fit_tech+')~[ km~s^{-1}]$',fontsize=22);
if(Fit_tech=='etaMLE'):plt.ylabel('$B(\eta MLE)~[ km~s^{-1}]$',fontsize=22);
plt.xlabel('$B_{true}~[ km~s^{-1}]$',fontsize=22);
plt.xticks(fontsize=16);
plt.yticks(fontsize=16);
plt.grid(True)
plt.savefig('/Users/fei/WSP/Scie/Proj5/Results/BKmock'+Fit_tech+'.pdf', dpi=150, bbox_inches='tight')
plt.show()


# 5. out put:------------------------------------------------------------------
outfile = open(output_dir+Fit_tech+'.txt', 'w')
outfile.write("#Vx     Vy     Vz     eVx     eVy     eVz     sigma_star\n")
for i in range(2*nfiles):
    outfile.write("%12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf\n"
                  %(B_opt[0,i],  B_opt[1,i],   B_opt[2,i],   PyerrB[0,i], PyerrB[1,i],  PyerrB[2,i],Sv_opt[i],Sv_MC[i]))
outfile.close()
