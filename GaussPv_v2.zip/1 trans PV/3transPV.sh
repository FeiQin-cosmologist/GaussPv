#!/bin/bash
#SBATCH --job-name=tras_v
#SBATCH --ntasks=1
#SBATCH --array=0-16
#SBATCH --time=75:00:00
#SBATCH --mem-per-cpu=8G
#SBATCH --mail-type=end
#SBATCH --mail-user=feiqin@kasi.re.kr
#SBATCH --output=slurmout/cf4_slurm%J.out


module load numpy/1.14.1-python-2.7.14
module load scipy/1.0.0-python-2.7.14
srun python 2transPV.py ${SLURM_ARRAY_TASK_ID}
