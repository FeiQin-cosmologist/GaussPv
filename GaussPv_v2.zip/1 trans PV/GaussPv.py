import numpy as np
import scipy as sp
from scipy.interpolate import splev, splrep
from scipy import integrate
import math
from scipy import stats
from CosmoFunc import *
#import matplotlib.pyplot as plt
 




# cosmilogy function-----------------------------------------------------------
def spline_Dis2Rsf(OmegaM,OmegaA,Hub,nbin=10000,redmax=2.5):
    dist = np.empty(nbin);red = np.empty(nbin)
    for j in range(nbin):
        red[j] = j*redmax/nbin
        dist[j] = DistDc(red[j],OmegaM,OmegaA, 0.0,Hub,-1.0, 0.0, 0.0)
    rsf_spline = sp.interpolate.splrep(dist,red,  s=0)
    return rsf_spline
def spline_Rsf2Dis(OmegaM,OmegaA,Hub,nbin=10000,redmax=2.5):
    dist = np.empty(nbin);red = np.empty(nbin)
    for j in range(nbin):
        red[j] = j*redmax/nbin
        dist[j] = DistDc(red[j],OmegaM,OmegaA, 0.0,Hub,-1.0, 0.0, 0.0)
    dist_spline = sp.interpolate.splrep(red, dist, s=0)
    return dist_spline
def DRcon(xdt,types,OmegaMs,OmegaAs,Hubs):
    x=np.linspace(-1.,100.,1000)
    y=np.zeros(len(x))
    for i in range(len(x)): 
        y[i]=DistDc(x[i],OmegaMs,OmegaAs, 0.0,Hubs,-1.0, 0.0, 0.0)
    spl_z2d = splrep(x, y, s=0)
    spl_d2z = splrep(y, x, s=0)
    if(types=='z2d'):
        Distc        = splev(xdt, spl_z2d)
        return Distc
    if(types=='d2z'):
        RSFs        = splev(xdt, spl_d2z)
        return RSFs
def Vpec_Fun(Rsf,Logd,OmegaM,OmegaA, Hub):
    dz=DRcon(Rsf,'z2d',OmegaM,OmegaA, Hub)
    dh=dz*10.0**(-Logd)
    zh=DRcon(dh,'d2z',OmegaM,OmegaA, Hub)
    v=LightSpeed *( Rsf - zh )/( 1.0 + zh )
    return v
def Vpec_Fun_wat(Rsf,Logd,OmegaM,OmegaA, Hub):
    deccel = 3.0*OmegaM/2.0 - 1.0
    Vmod   = Rsf*LightSpeed*(1.0 + 0.5*(1.0 - deccel)*Rsf - (2.0 - deccel - 3.0*deccel*deccel)*Rsf*Rsf/6.0)
    vpec   = math.log(10.)*Vmod/(1.0+Vmod/LightSpeed) * Logd
    return vpec










# PDF function:----------------------------------------------------------------
def P_eta(x,mu,sigma):    
    y=1.0/np.sqrt(2.0 * math.pi * sigma**2 ) * np.exp(  -(x - mu )**2 / (2.0*sigma**2)  )
    return y
def Pv_FUN(z,mu_eta,sigma_eta,eta,OmegaM,OmegaA, Hub,spl_z2d,spl_d2z):
    Peta=P_eta(eta,mu_eta,sigma_eta)
    dz=splev(z, spl_z2d ) 
    dh=dz*10.0**(-eta)
    zh=splev(dh, spl_d2z )  
    Pv=Peta/(np.log(10.)*dh)    *   LightSpeed/Hub   *    1./np.sqrt(   OmegaM*(1.+zh)**3+OmegaA  )   *   (1.+zh)**2/(LightSpeed*(1.+z))
    #Pv=Peta/(np.log(10.)*dh)    *   LightSpeed              / (   99.939 + 0.01636 * dh  )            *   (1.+zh)**2/(LightSpeed*(1.+z))
    v=LightSpeed *( z - zh )/( 1.0 + zh )
    intg=0.;     
    return Pv[np.argsort(v)],v[np.argsort(v)]
def Pv_spl(x,vc,Pvc):
    Pvspl=splrep(vc,np.log(Pvc),s=0)  
    y = splev(x, Pvspl)
    return np.exp(y)
def PDFv(eta,z,mu_eta,sigma_eta,OmegaM,OmegaA, Hub,spl_z2d,spl_d2z):
    Pvs,vs=Pv_FUN(z,mu_eta,sigma_eta,eta,OmegaM,OmegaA, Hub,spl_z2d,spl_d2z)
    vy   = np.linspace(np.min(vs),np.max(vs),len(vs))
    Pvy  = np.interp(vy,vs,Pvs) 
    nom  = 1.#C_nom(vy,Pvy)
    return Pvy/nom,vy,nom
def C_nom(vc,Pvc):
    return integrate.quad(Pv_spl, np.min(vc), np.max(vc) , args=(vc,Pvc))[0]













# Gaussianizing finction:------------------------------------------------------
def V_sampler(CDFx,vy,Pvy):
    Cdfs = np.cumsum(Pvy) ; Cdfs = Cdfs/np.max(Cdfs)
    V_sample = np.interp(CDFx,Cdfs ,vy )  
    return V_sample,CDFx

def Vp_BCsamp(NVp_Sp,N_spls,deltmm,deltyp,z,logd,elogd,OmegaM,OmegaA, Hub,Out_Vsamp=False,output_dir_Vsamp=np.nan):
    Ngal   = len(z)          ; maxV   = np.zeros( 2 )  
    BC_Vp  = np.zeros(Ngal)  ; eBC_Vp = np.zeros(Ngal) ; BC_nu  = np.zeros(Ngal) ; BC_d = np.zeros(Ngal)
    breakFlag=np.zeros(Ngal,dtype=int)
    if(Out_Vsamp):
        Vp_sp_out = np.zeros((Ngal,NVp_Sp)) ; CDF_v_out = np.zeros((Ngal,NVp_Sp)) ; BC_vsp_out = np.zeros((Ngal,NVp_Sp)) 
    spl_z2d = spline_Rsf2Dis(OmegaM,OmegaA,Hub,nbin=10000,redmax=1.)
    spl_d2z = spline_Dis2Rsf(OmegaM,OmegaA,Hub,nbin=10000,redmax=1.)
    Vp_orig = Vpec_Fun(z,logd,OmegaM,OmegaA, Hub)
    np.random.seed(19)
    CDFrand = np.random.random(NVp_Sp)
    for igal in range(Ngal):
        #eta           = np.linspace(logd[igal]-60*elogd[igal],logd[igal]+25*elogd[igal],N_spls)
        eta           = np.linspace(logd[igal]-65*elogd[igal],logd[igal]+30*elogd[igal],N_spls)
        Peta          = P_eta(eta,logd[igal],elogd[igal])
        Pvp,Vp,Norm   = PDFv(eta,z[igal],logd[igal],elogd[igal],OmegaM,OmegaA, Hub,spl_z2d,spl_d2z)
        Pvp[Pvp<=10**(-15)]=10**(-15)  ; Vp=Vp[Pvp>(1e-15)]  ; Pvp=Pvp[Pvp>(1e-15)]
        Vp_sp , CDF_v = V_sampler(CDFrand,Vp,Pvp)
        if(Out_Vsamp):
            Vp_sp_out[igal,:] , CDF_v_out[igal,:] = Vp_sp , CDF_v  
        if(deltyp=='PvR'):    
            maxPv = np.max(Pvp)                   ;  maxV[0] = Vp[Pvp==maxPv] 
            inds  = np.where(Pvp>=(0.1*maxPv))[0] ;  maxV[1] = np.min(Vp[inds]) 
            ds         = np.abs(maxV[0]-maxV[1])
            BC_d[igal] = deltmm*ds  
            temps      = Vp_sp+ BC_d[igal]
            inds       = np.where(temps>0)[0]
            Nvsm       = len(Vp_sp) 
            if((Nvsm-len(inds))>((0.0005*Nvsm))):
                print(igal, 'delta is too small!!!',(Nvsm-len(inds)),'/',Nvsm)
                breakFlag[igal]=int(1)
            BC_vsp , BC_nu[igal] = stats.boxcox(temps[inds])
        if(deltyp=='PvMin'): 
            if(np.min(Vp_sp)<=0.):
                BC_d[igal] = deltmm*np.abs(np.min(Vp_sp)) 
            else:
                BC_d[igal] = 0.
            temps      = Vp_sp+ BC_d[igal]
            BC_vsp , BC_nu[igal] = stats.boxcox(temps)            
        BC_Vp[igal] = (( Vp_orig[igal] + BC_d[igal] )**BC_nu[igal]-1.0)/BC_nu[igal]  
        eBC_Vp[igal]  = np.std(BC_vsp) 
        if(Out_Vsamp):
            if(deltyp=='PvR'): BC_vsp_out[igal,inds] = BC_vsp
            if(deltyp=='PvMin'):BC_vsp_out[igal,:] = BC_vsp
    if(Out_Vsamp):
        outfile1 = np.save(output_dir_Vsamp, [CDF_v_out, Vp_sp_out, BC_vsp_out],  allow_pickle=True)       
    return  BC_Vp,eBC_Vp,BC_nu,BC_d  ,breakFlag






def PDF_BC_lambda(xss,x_d,Low_lbd,Up_lbd,Nps):   
    lmbdas = np.linspace(Low_lbd,Up_lbd,Nps)
    llf = np.zeros(lmbdas.shape, dtype=float)
    for ii, lmbda in enumerate(lmbdas):
        llf[ii] = stats.boxcox_llf(lmbda, xss+x_d)
    return lmbdas,llf 


    
  
        
        
        
        
        
