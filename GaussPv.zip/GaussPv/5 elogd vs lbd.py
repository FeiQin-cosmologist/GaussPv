import numpy as np
import matplotlib.pyplot as plt
from GaussPv import *




Data_type ='Mock'# 'Survey'#    
nfile     = 8




input_dir       = '/Users/fei/WSP/Scie/Proj5/Data/Prod/GaussPv/2MTF_bc'
input_dir_mock  = '/Users/fei/WSP/Scie/Proj5/Data/Prod/GaussPv/2MTFmock_bc'
 
output_dir      = '/Users/fei/WSP/Scie/Proj5/Data/Prod/lbd_elogd.txt'




#------------------------------------------------------------------------------
print(Data_type)
if(Data_type=='Survey'): 
    infile=np.loadtxt(input_dir)  
    ra     = infile[:,0]
    dec    = infile[:,1]
    cz     = infile[:,2]  
    logd   = infile[:,3]  
    elogd  = infile[:,4]
    Vp_new = infile[:,5]
    eVp_new= infile[:,6]
    lbd    = infile[:,7]
    delt   = infile[:,8]
    Ngal     = len(ra)
    
    
    Omega_M=0.305
    Omega_A=1.0-Omega_M
    Hubl   = 100.
    
    Vpec = Vpec_Fun(cz/LightSpeed,logd,Omega_M,Omega_A, Hubl)
    dz   = DRcon(cz/LightSpeed,'z2d',Omega_M,Omega_A,Hubl)
    dh   = dz*10.0**(-logd)
    

            
    plt.figure(1,figsize=(9,6))
    plt.scatter(elogd,lbd,s=8,label='data')
    plt.xlabel('$\epsilon$',fontsize=22);
    plt.ylabel('$\lambda$',fontsize=22);  
    Xmin,Xmax=0.04,0.18
    x=np.linspace(Xmin,Xmax,100)
    k,b=np.polyfit(elogd,lbd, deg=1)
    print(k,b)
    y= k * x + b
    plt.plot(x,y,linewidth=3,ls="-", c='gold' ,label='fit')
    plt.xlim(Xmin,Xmax)
    plt.ylim(1,10)
    plt.text(0.06,8.0 , 'fit:$~\lambda=33.2\epsilon+0.4144}$' ,fontsize=22,c='k')
    plt.legend(fontsize=20) 
    plt.xticks(fontsize=16);  
    plt.yticks(fontsize=16); 
    #plt.grid(True)
    plt.savefig('/Users/fei/WSP/Scie/Proj5/Results/lbd_vs_elogd.pdf', dpi=150, bbox_inches='tight') 
    plt.show()                
    
    outfile = open(output_dir, 'w')  
    for i in range(len(lbd)):
            outfile.write("%12.6lf  %12.6lf  %12.6lf  %12.6lf \n"%(lbd[i],  elogd[i],   dh[i],dz[i]))
    outfile.close()
    
outfile = open(output_dir+'_mock', 'w')    
if(Data_type=='Mock'): 
  plt.figure(1,figsize=(9,6))
  for i_mock in range(2*nfile):    
    if(i_mock<=7):
        Omega_M= 0.273
        Omega_A= 1.0-Omega_M
        Hubl   = 100.
        indir  = input_dir_mock+str(i_mock)
        print('GiggleZ',str(i_mock))
    else:
        Omega_M= 0.3121
        Omega_A= 1.0-Omega_M
        Hubl   = 100.
        indir  = input_dir_mock+str(i_mock-8)
        print('Surfs',str(i_mock-8))
    infile= np.loadtxt(indir)
    ra     = infile[:,0]
    dec    = infile[:,1]
    cz     = infile[:,2]  
    logd   = infile[:,3]  
    elogd  = infile[:,4]
    Vp_new = infile[:,5]
    eVp_new= infile[:,6]
    lbd    = infile[:,7]
    delt   = infile[:,8]
    Ngal     = len(ra)
    
    Vpec = Vpec_Fun(cz/LightSpeed,logd,Omega_M,Omega_A, Hubl)
    dz   = DRcon(cz/LightSpeed,'z2d',Omega_M,Omega_A,Hubl)
    dh   = dz*10.0**(-logd)
    

    plt.scatter(elogd,lbd,s=1)
    if(i_mock==15):
        plt.xlabel('$\epsilon$',fontsize=22);
        plt.ylabel('$\lambda$',fontsize=22);  
        Xmin,Xmax=0.0,0.18
        x=np.linspace(Xmin,Xmax,100)
        k,b=np.polyfit(elogd,lbd, deg=1)
        print(k,b)
        y= k * x + b
        plt.plot(x,y,linewidth=3,ls="-", c='b' ,label='fit')
        plt.xlim(Xmin,Xmax)
        plt.ylim(1,9)
        plt.text(0.03,7, 'fit:$~\lambda=27.7\epsilon+0.927$' ,fontsize=22,c='k')
        plt.legend(fontsize=20) 
        plt.xticks(fontsize=16);  
        plt.yticks(fontsize=16); 
        #plt.grid(True)
        plt.savefig('/Users/fei/WSP/Scie/Proj5/Results/lbd_vs_elogd_mock.pdf', dpi=150, bbox_inches='tight')
  


    for i in range(len(lbd)):
        outfile.write("%12.6lf  %12.6lf  %12.6lf  %12.6lf \n"%(lbd[i],  elogd[i],   dh[i],dz[i]))

outfile.close()
plt.show()






