import sys
import numpy as np
from CosmoFunc import *
from GaussPv import *
#------------------------------------------------------------------------------










Data_type        = 'Mock'#'Survey'#
out_Vsamp        = False
deltadj          = 1.0001  #   10   #
deltatyp         = 'PvMin'   #   'PvR'    #





input_dir_mock   = '/fred/oz074/fqdata/mocks/CF4TFmocks/CF4TF_mock'
output_dir_mock  = '/fred/oz074/fqdata/Prod/GaussPv/CF4mock_bc'









#=============================      Main Code      ============================
NVp_Sp=285310
N_spls=3000
print(Data_type)
# 1: Mock surveys:-------------------------
if(Data_type=='Mock'):
 Omega_M= 0.3121  ;  Omega_A= 1.0-Omega_M  ;  Hubl   = 100.
 
 
 Arg_ID=int(sys.argv[1])
 Imock=15
 Jmock=8
 Ncpu =17
 Nrun =0
    
    
 Nmock=Jmock*Imock
 for imks in range(Imock):
  i_mock= imks +  19000 + Imock*Ncpu*Nrun + Imock * Arg_ID
  for j_mock in range(Jmock):
    print('mock:',str(i_mock)+'.'+str(j_mock))
    input_dir = input_dir_mock+str(i_mock)+'.'+str(j_mock)
    infilm= np.loadtxt(input_dir)
    outdir= output_dir_mock+str(i_mock)+'.'+str(j_mock)
    ID    = infilm[:,0]
    RA    = infilm[:,1]
    DEC   = infilm[:,2]
    cz    = infilm[:,3];z=cz/LightSpeed
    logdt = infilm[:,4]
    logd  = infilm[:,5]
    elogd = infilm[:,6]
    Vpec  = Vpec_Fun(cz/LightSpeed,logd,Omega_M,Omega_A, Hubl)
    Ngal  = len(RA) 
    if(out_Vsamp):
        out_Vsamp_dir = output_dir_Vsamp+'mock_bc'+str(i_mock)+'.'+str(j_mock)
    else:
        out_Vsamp_dir = np.nan
    Vp_new, eVp_new,Lambd, Delta = Vp_BCsamp(NVp_Sp,N_spls,deltadj,deltatyp,z,logd,elogd,Omega_M,Omega_A, Hubl,out_Vsamp,out_Vsamp_dir)

    outfile = open(outdir, 'w')
    outfile.write("#ra      dec     cz     logd     elogd     Vpec_bc     eVpec_bc    bc_nv      bc_d\n")
    for i in range(Ngal):
        outfile.write("%12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf\n" % (RA[i],DEC[i],cz[i],logd[i],elogd[i],Vp_new[i],eVp_new[i],Lambd[i], Delta[i]))
    outfile.close()
    
    
