import numpy as np
from CosmoFunc import *
from GaussPv import *
#------------------------------------------------------------------------------










Data_type        = 'Mock'#  'Survey'#
Nmock            = 16
Trans_Type       = 'BC'  #'YJ'  #       

input_dir        = '/Users/fei/WSP/Scie/Proj5/Data/Orig/2MTF_pkin_clipped.dat'
input_dir_mock   = '/Users/fei/WSP/Scie/Proj5/Data/Orig/2MTF Mock/'
output_dir_Vsamp = '/Users/fei/WSP/Scie/Proj5/Data/Prod/Vsamp/2MTF_Vsamp'
if(Trans_Type   ==  'BC'):
  output_dir     = '/Users/fei/WSP/Scie/Proj5/Data/Prod/GaussPv/2MTF_bc'
  output_dir_mock= '/Users/fei/WSP/Scie/Proj5/Data/Prod/GaussPv/2MTFmock_bc'
if(Trans_Type   ==  'YJ'):
  output_dir     = '/Users/fei/WSP/Scie/Proj5/Data/Prod/GaussPv/2MTF_yj'
  output_dir_mock= '/Users/fei/WSP/Scie/Proj5/Data/Prod/GaussPv/2MTFmock_yj'











#=============================      Main Code      ============================
NVp_Sp=150000
N_spls=1000
print(Data_type,Trans_Type)
# 1: Real surveys:-------------------------------------------------------------
if(Data_type=='Survey'):
    Omega_M= 0.307
    Omega_A= 1.0-Omega_M
    Hubl   = 100.
    infile=np.loadtxt(input_dir) 
    RA   = infile[:,0]   
    DEC  = infile[:,1]  
    cz   = infile[:,2]  
    logd = infile[:,3]  
    elogd= infile[:,4]   
    Vpec = Vpec_Fun(cz/LightSpeed,logd,Omega_M,Omega_A, Hubl)
    #Vpec_wat =  Vpec_Fun_wat(cz/LightSpeed,logd,Omega_M,Omega_A, Hubl)
    Ngal = len(RA) 
    Vp_sp,CDF_v,maxPv,maxV=Vp_samp(NVp_Sp,N_spls,cz/LightSpeed,logd,elogd,Omega_M,Omega_A, Hubl)

    if(Trans_Type   ==  'BC'):
        Vp_new,Lambd, Delta ,vsp = Vp_BC(Ngal,Vpec,Vp_sp,maxPv,maxV,5)
        outfile = open(output_dir, 'w')
        outfile.write("#ra      dec     cz     logd     elogd     Vpec_bc     eVpec_bc    bc_nv      bc_d\n")
        for i in range(Ngal):
            outfile.write("%12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf\n" % (RA[i],DEC[i],cz[i],logd[i],elogd[i],Vp_new[i],np.std(vsp[i,:]),Lambd[i], Delta[i]))
        outfile.close() 
        outfile1 = np.save(output_dir_Vsamp+'_bc', [CDF_v, Vp_sp, vsp],  allow_pickle=True)
    if(Trans_Type   ==  'YJ'):
        Vp_new,Lambd ,vsp= Vp_YJ(Ngal,Vpec,Vp_sp) 
        outfile = open(output_dir, 'w')
        outfile.write("#ra      dec     cz     logd     elogd     Vpec_yj     eVpec_yj    bc_yj \n")
        for i in range(Ngal):
            outfile.write("%12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf \n" % (RA[i],DEC[i],cz[i],logd[i],elogd[i],Vp_new[i],np.std(vsp[i,:]),Lambd[i]))
        outfile.close() 
        outfile2 = np.save(output_dir_Vsamp+'_yj', [CDF_v, Vp_sp, vsp],  allow_pickle=True)   
    
# 2: Mock surveys:-------------------------------------------------------------
if(Data_type=='Mock'):
  for i_mock in range(4):
    i_mock=i_mock +12
    if(i_mock<=7):
        Omega_M= 0.273
        Omega_A= 1.0-Omega_M
        Hubl   = 100.
        indir  = input_dir_mock+'GiggleZ_2MTF.'+str(i_mock)
        print('GiggleZ',str(i_mock))
    else:
        Omega_M= 0.3121
        Omega_A= 1.0-Omega_M
        Hubl   = 100.
        indir  = input_dir_mock+'Surfs_2MTF.'+str(i_mock-8)
        print('Surfs',str(i_mock-8))
    outdir = output_dir_mock+str(i_mock)
    infilm= np.loadtxt(indir)
    ID    = infilm[:,0]
    RA    = infilm[:,1]
    DEC   = infilm[:,2]
    cz    = infilm[:,3]
    logdt = infilm[:,4]
    logd  = infilm[:,5]
    elogd = infilm[:,6]
    Vpec  = Vpec_Fun(cz/LightSpeed,logd,Omega_M,Omega_A, Hubl)
    Ngal  = len(RA)     
    Vp_sp,CDF_v,maxPv,maxV=Vp_samp(NVp_Sp,N_spls,cz/LightSpeed,logd,elogd,Omega_M,Omega_A, Hubl)
    if(Trans_Type   ==  'BC'):
        Vp_new,Lambd, Delta ,vsp = Vp_BC(Ngal,Vpec,Vp_sp,maxPv,maxV,5)
        outfile = open(outdir, 'w')
        outfile.write("#ra      dec     cz     logd     elogd     Vpec_bc     eVpec_bc    bc_nv      bc_d\n")
        for i in range(Ngal):
            outfile.write("%12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf\n" % (RA[i],DEC[i],cz[i],logd[i],elogd[i],Vp_new[i],np.std(vsp[i,:]),Lambd[i], Delta[i]))
        outfile.close()
        outfile1 = np.save(output_dir_Vsamp+'mock_bc'+str(i_mock), [CDF_v, Vp_sp, vsp],  allow_pickle=True)
    if(Trans_Type   ==  'YJ'):
        Vp_new,Lambd ,vsp= Vp_YJ(Ngal,Vpec,Vp_sp)
        outfile = open(outdir, 'w')
        outfile.write("#ra      dec     cz     logd    elogd    Vpec_bc     eVpec_bc    yj_nv\n")
        for i in range(Ngal):
            outfile.write("%12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf  %12.6lf\n" % (RA[i],DEC[i],cz[i],logd[i],elogd[i],Vp_new[i],np.std(vsp[i,:]),Lambd[i]))
        outfile.close()
        outfile2 = np.save(output_dir_Vsamp+'mock_yj'+str(i_mock), [CDF_v, Vp_sp, vsp],  allow_pickle=True)


   
    
