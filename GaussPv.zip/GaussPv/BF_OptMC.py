import math
import numpy as np
import emcee
import scipy as sp
from itertools import chain
from CosmoFunc import *
from scipy.interpolate import splev, splrep

def DRcon(xdt,types,OmegaMs,OmegaAs,Hubs):
    x=np.linspace(-1.,100.,1000)
    y=np.zeros(len(x))
    for i in range(len(x)): 
        y[i]=DistDc(x[i],OmegaMs,OmegaAs, 0.0,Hubs,-1.0, 0.0, 0.0)
    spl_z2d = splrep(x, y, s=0)
    spl_d2z = splrep(y, x, s=0)
    if(types=='z2d'):
        Distc        = splev(xdt, spl_z2d)
        return Distc
    if(types=='d2z'):
        RSFs        = splev(xdt, spl_d2z)
        return RSFs
def Vpec_Fun_tra(Rsf,Logd,OmegaM,OmegaA, Hub):
    dz=DRcon(Rsf,'z2d',OmegaM,OmegaA, Hub)
    dh=dz*10.0**(-Logd)
    zh=DRcon(dh,'d2z',OmegaM,OmegaA, Hub)
    v=LightSpeed *( Rsf - zh )/( 1.0 + zh )
    return v
def Vpec_Fun_wat(Rsf,Logd,OmegaM,OmegaA, Hub):
    deccel = 3.0*OmegaM/2.0 - 1.0
    Vmod   = Rsf*LightSpeed*(1.0 + 0.5*(1.0 - deccel)*Rsf - (2.0 - deccel - 3.0*deccel*deccel)*Rsf*Rsf/6.0)
    vpec   = math.log(10.)*Vmod/(1.0+Vmod/LightSpeed) * Logd
    return vpec


def lnprior(params):
    Bx, By, Bz,sigma_star_vp = params    
    interval_v = 1200.0 # must greater than 0.   
    # Flat prior for Bx
    if (-interval_v <= Bx <= interval_v):
        Bx_prior = 1.0/(2.0*interval_v)
    else:
        return -np.inf   
    # Flat prior for By
    if (-interval_v <= By <= interval_v):
        By_prior = 1.0/(2.0*interval_v)
    else:
        return -np.inf   
    # Flat prior for Bz
    if (-interval_v <= Bz <= interval_v):
        Bz_prior = 1.0/(2.0*interval_v)
    else:
        return -np.inf    
    # Flat prior for sigma_star_vp
    if (0.0 <= sigma_star_vp <= interval_v):
        sigma_star_vp_prior = 1.0/interval_v
    else:
        return -np.inf
    return 0.0


# 2: Qin MLE:------------------------------------------------------------------
def lnlike_qMLE(params,hatr,vpec,EV,nvs,detls,typs):
    Bx, By, Bz, sigma_star_vp = params
    Vps       = Bx* hatr[0,:]  +By*hatr[1,:]  +Bz*hatr[2,:]
    XC        = Vps+detls 
    #if(XC<0):
    #    objval=-1.*np.infty
    #    if(typs=='MCMC'):
    #        return objval
    #    if(typs=='Opt'):
    #        return -1.*objval        
    #if(XC>=0):
    #    Vp      = (XC**nvs-1.0) / nvs  
    Vp = np.zeros(len(Vps))      
    Vp[XC>=0.]= (XC[XC>=0.]**nvs[XC>=0.]-1.0) / nvs[XC>=0.]
    Vp[XC< 0.]= (-np.abs(XC[XC< 0.])**nvs[XC< 0.]-1.0) / nvs[XC< 0.]  
    evpec2  = EV**2+sigma_star_vp**2
    LnPeta  = -np.log(np.sqrt(2.*math.pi*evpec2))-(Vp-vpec)*(Vp-vpec)/(2.*evpec2)
    objval  = np.nansum(LnPeta)
    if(typs=='MCMC'):
        return objval
    if(typs=='Opt'):
        return -1.*objval
def lnpost_qMLE(params,hatr,vpec,EV,nvs,detls,typs):
    prior = lnprior(params)
    if not np.isfinite(prior):
        return -np.inf
    like = lnlike_qMLE(params,hatr,vpec,EV,nvs,detls,typs)
    return prior + like



# 3: Eta MLE:------------------------------------------------------------------
def lnlike_etaMLE(params,hatr,logd,elogd,z,dz,EZ,Hub,dist_spline,typs):    
    Bx, By, Bz, sigma_star_vp = params
    Vp = Bx* hatr[0,:]  +By*hatr[1,:]  +Bz*hatr[2,:]
    zh    =  (z-Vp/LightSpeed)  / (1. + Vp/LightSpeed)
    dh    =  sp.interpolate.splev(zh,dist_spline)
    inds = np.where(np.isnan(dh))
    dh[inds]=dz[inds]
    inds = np.where(dh<=0.)
    dh[inds]=dz[inds]    
    ETA= np.log10(dz/dh)
    elogd2 = elogd**2 + (sigma_star_vp/np.log(10.) * (1.+z)/(Hub*EZ*dz))**2
    LnPeta=-np.log(np.sqrt(2.*math.pi*elogd2))-(ETA-logd)*(ETA-logd)/(2.*elogd2)
    objval=np.nansum(LnPeta)   
    if(typs=='MCMC'):
        return objval
    if(typs=='Opt'):
        return -1.*objval
def lnpost_etaMLE(params,hatr,logd,elogd,z,dz,EZ,Hub,dist_spline,typs):    
    prior = lnprior(params)
    if not np.isfinite(prior):
        return -np.inf
    like = lnlike_etaMLE(params,hatr,logd,elogd,z,dz,EZ,Hub,dist_spline,typs)
    return prior + like



# 4: wat MLE:------------------------------------------------------------------
def lnlike_wMLE(params,hatr,vpec,EV,typs): 
    Bx, By, Bz, sigma_star_vp = params
    Vp = Bx* hatr[0,:]  +By*hatr[1,:]  +Bz*hatr[2,:]
    evpec2 = EV**2+sigma_star_vp**2
    LnPeta=-np.log(np.sqrt(2.*math.pi*evpec2))-(Vp-vpec)*(Vp-vpec)/(2.*evpec2)
    objval=np.sum(LnPeta)
    if(typs=='MCMC'):
        return objval
    if(typs=='Opt'):
        return -1.*objval
    return objval
def lnpost_wMLE(params,hatr,vpec,EV,typs):
    prior = lnprior(params)
    if not np.isfinite(prior):
        return -np.inf
    like = lnlike_wMLE(params,hatr,vpec,EV,typs)
    return prior + like




# 5 Optimize:------------------------------------------------------------------
def hatr_Fun(ra,dec):
    hatr      = np.array([[0.]*len(ra)]*3)
    hatr[0,:] = np.cos(math.pi*dec/180.0)*np.cos(math.pi*ra/180.0)
    hatr[1,:] = np.cos(math.pi*dec/180.0)*np.sin(math.pi*ra/180.0)
    hatr[2,:] = np.sin(math.pi*dec/180.0)
    return hatr
def Opt_qMLE(ra,dec,vpec,EV,nvs,detls): 
    typs      = 'Opt'
    hatr      = hatr_Fun(ra,dec)
    outpf     = sp.optimize.minimize(lnlike_qMLE,[200.,200.,200.,300.],args=(hatr,vpec,EV,nvs,detls,typs),method='Nelder-Mead',tol=10.**(-11))
    Ux        = outpf.x[0]  ;  Uy = outpf.x[1]  ;  Uz = outpf.x[2]
    sigv      = outpf.x[3]
    return   np.asarray([Ux,Uy,Uz  ]) ,sigv 
def Opt_etaMLE(ra,dec,z,logd,elogd,OmegaM,OmegaA,Hub): 
    dz = np.zeros(len(z));    EZ    = np.zeros(len(z)); 
    for j in range(len(z)):
        EZ[j] = Ez(z[j], OmegaM,OmegaA, 0.0, -1.0, 0.0, 0.0)
        dz[j] = DistDc(z[j],OmegaM,OmegaA, 0.0,Hub,-1.0, 0.0, 0.0)
    dist = np.empty(2000);red = np.empty(2000)
    for j in range(2000):
        red[j] = j*0.4/2000
        dist[j] = DistDc(red[j],OmegaM,OmegaA, 0.0,Hub,-1.0, 0.0, 0.0)
    dist_spline = sp.interpolate.splrep(red, dist, s=0)    
    typs      = 'Opt'
    hatr      = hatr_Fun(ra,dec)
    outpf     = sp.optimize.minimize(lnlike_etaMLE,[200.,200.,200.,300.],args=(hatr,logd,elogd,z,dz,EZ,Hub,dist_spline,typs),method='Nelder-Mead',tol=10.**(-11))
    Ux        = outpf.x[0]  ;  Uy = outpf.x[1]  ;  Uz = outpf.x[2]
    sigv      = outpf.x[3]
    return   np.asarray([Ux,Uy,Uz  ]) ,sigv   
def Opt_wMLE(ra,dec,vpec,Ev): 
    typs      = 'Opt'
    hatr      = hatr_Fun(ra,dec)
    outpf     = sp.optimize.minimize(lnlike_wMLE,[200.,200.,200.,300.],args=(hatr,vpec,Ev,typs),method='Nelder-Mead',tol=10.**(-11))
    Ux        = outpf.x[0]  ;  Uy = outpf.x[1]  ;  Uz = outpf.x[2]
    sigv      = outpf.x[3]
    return   np.asarray([Ux,Uy,Uz]), sigv 
def Opt_tMLE(ra,dec,vpec,Ev): 
    a,b       = Opt_wMLE(ra,dec,vpec,Ev)
    return   a,b      
    
    
# 6 MCMC:---------------------------------------------------------------------- 
def MCparm(ndim, nwalkers):
    begin = [[200.0*np.random.rand()-100.0,
              200.0*np.random.rand()-100.0,
              200.0*np.random.rand()-100.0,
              200.0*np.random.rand()+200.0] for k in range(nwalkers)]#
    return begin
def MC_qMLE(ra,dec,vpec,EV,nvs,detls): 
    typs      = 'MCMC'
    hatr      = hatr_Fun(ra,dec)
    ndim=4   ;    nwalkers=24
    begin     = MCparm(ndim=4, nwalkers=24)
    sampler   = emcee.EnsembleSampler(nwalkers, ndim, lnpost_qMLE, args=[hatr,vpec,EV,nvs,detls,typs])
    pos, prob, state = sampler.run_mcmc(begin, 3000)
    sampler.reset()
    sampler.run_mcmc(pos, 100000)
    # the output of MCMC:
    Ux = np.mean(sampler.flatchain[:,0])
    Uy = np.mean(sampler.flatchain[:,1])
    Uz = np.mean(sampler.flatchain[:,2])
    U_cov = np.cov([sampler.flatchain[:,0],sampler.flatchain[:,1],sampler.flatchain[:,2]])
    sigv =np.mean(sampler.flatchain[:,3])
    return   np.asarray([Ux,Uy,Uz]) ,sigv , U_cov, sampler.flatchain[:,0],sampler.flatchain[:,1],sampler.flatchain[:,2],sampler.flatchain[:,3]
def MC_etaMLE(ra,dec,z,logd,elogd,OmegaM,OmegaA,Hub): 
    dz = np.zeros(len(z));    EZ    = np.zeros(len(z)); 
    for j in range(len(z)):
        EZ[j] = Ez(z[j], OmegaM,OmegaA, 0.0, -1.0, 0.0, 0.0)
        dz[j] = DistDc(z[j],OmegaM,OmegaA, 0.0,Hub,-1.0, 0.0, 0.0)
    dist = np.empty(2000);red = np.empty(2000)
    for j in range(2000):
        red[j] = j*0.4/2000
        dist[j] = DistDc(red[j],OmegaM,OmegaA, 0.0,Hub,-1.0, 0.0, 0.0)
    dist_spline = sp.interpolate.splrep(red, dist, s=0)
    typs      = 'MCMC'
    hatr      = hatr_Fun(ra,dec)
    ndim=4   ;    nwalkers=24
    begin     = MCparm(ndim=4, nwalkers=24)
    sampler   = emcee.EnsembleSampler(nwalkers, ndim, lnpost_etaMLE, args=[hatr,logd,elogd,z,dz,EZ,Hub,dist_spline,typs])
    pos, prob, state = sampler.run_mcmc(begin, 3000)
    sampler.reset()
    sampler.run_mcmc(pos, 100000)
    # the output of MCMC:
    Ux = np.mean(sampler.flatchain[:,0])
    Uy = np.mean(sampler.flatchain[:,1])
    Uz = np.mean(sampler.flatchain[:,2])
    U_cov = np.cov([sampler.flatchain[:,0],sampler.flatchain[:,1],sampler.flatchain[:,2]])
    sigv =np.mean(sampler.flatchain[:,3])
    return   np.asarray([Ux,Uy,Uz]) ,sigv , U_cov, sampler.flatchain[:,0],sampler.flatchain[:,1],sampler.flatchain[:,2],sampler.flatchain[:,3]
def MC_wMLE(ra,dec,vpec,EV): 
    typs      = 'MCMC'
    hatr      = hatr_Fun(ra,dec)
    ndim=4   ;    nwalkers=24
    begin     = MCparm(ndim=4, nwalkers=24)
    sampler   = emcee.EnsembleSampler(nwalkers, ndim, lnpost_wMLE, args=[hatr,vpec,EV,typs])
    pos, prob, state = sampler.run_mcmc(begin, 3000)
    sampler.reset()
    sampler.run_mcmc(pos, 100000)
    # the output of MCMC:
    Ux = np.mean(sampler.flatchain[:,0])
    Uy = np.mean(sampler.flatchain[:,1])
    Uz = np.mean(sampler.flatchain[:,2])
    U_cov = np.cov([sampler.flatchain[:,0],sampler.flatchain[:,1],sampler.flatchain[:,2]])
    sigv =np.mean(sampler.flatchain[:,3])
    return   np.asarray([Ux,Uy,Uz  ]) ,sigv, U_cov, sampler.flatchain[:,0],sampler.flatchain[:,1],sampler.flatchain[:,2],sampler.flatchain[:,3]
def MC_tMLE(ra,dec,vpec,Ev): 
    BF,Siv,CovBF,S0,S1,S2,S3=MC_wMLE(ra,dec,vpec,Ev)
    return   BF,Siv,CovBF,S0,S1,S2,S3


# 7 Jacbian error:------------------------------------------------------------- 
def BK_error(V_bkf,Reij):
    pi=math.pi
    V_bkf_mag=np.linalg.norm(V_bkf)
    Jaco=np.zeros(3) ; Jacop=np.zeros(3)
    Jaco[0] = V_bkf[0]/V_bkf_mag
    Jaco[1] = V_bkf[1]/V_bkf_mag
    Jaco[2] = V_bkf[2]/V_bkf_mag
    for j in range(3):
        Jacop[j] = 0.
        for i in range(3):
            Jacop[j] = Jacop[j]+Jaco[i]*Reij[i,j]
    suma=0.
    for j in range(3):
        suma = suma+Jacop[j]*Jaco[j]
    V_bkf_mag_err= np.sqrt(suma)
    #error of the bulkflow direction
    jaco_dir=np.zeros((2,3))
    jaco_dirpp=np.zeros(3)

    jaco_dir[0,0] = 180./pi*(-V_bkf[1])/(V_bkf[0]*V_bkf[0]*(1.+V_bkf[1]*V_bkf[1]/(V_bkf[0]*V_bkf[0])))
    jaco_dir[0,1] = 180./pi*1./(V_bkf[0]*(1.+V_bkf[1]*V_bkf[1]/(V_bkf[0]*V_bkf[0])))
    jaco_dir[0,2] = 0.
    jaco_dir[1,0] = 180./pi*(-V_bkf[2]*V_bkf[0])/(V_bkf_mag*V_bkf_mag*V_bkf_mag    * np.sqrt(1.-V_bkf[2]*V_bkf[2]/(V_bkf_mag*V_bkf_mag)))
    jaco_dir[1,1] = 180./pi*(-V_bkf[2]*V_bkf[1])/(V_bkf_mag*V_bkf_mag*V_bkf_mag    * np.sqrt(1.-V_bkf[2]*V_bkf[2]/(V_bkf_mag*V_bkf_mag)))
    jaco_dir[1,2] = 180./pi*(1./np.sqrt(1.-V_bkf[2]*V_bkf[2]/(V_bkf_mag*V_bkf_mag)))  * (V_bkf[2]*V_bkf[2]/(V_bkf_mag*V_bkf_mag*V_bkf_mag)-1./V_bkf_mag) #*(-1.)
 
    for j in range(3):
        jaco_dirpp[j]=0.
        for i in range(3):
            jaco_dirpp[j]=jaco_dirpp[j]+jaco_dir[ 0,i ]*Reij[ i,j ]
            
    suma=0.
    for j in range(3):
        suma = suma+jaco_dirpp[j]*jaco_dir[ 0,j ]
 
    longitude_bkf_err=np.sqrt(suma)

    for j in range(3):
        jaco_dirpp[j]=0.
        for i in range( 3):
            jaco_dirpp[j]=jaco_dirpp[j]+jaco_dir[ 1,i ]*Reij[ i,j ]

    suma=0.
    for j in range(3):
        suma = suma+jaco_dirpp[j]*jaco_dir[ 1,j ]
    latitude_bkf_err=np.sqrt(suma)

    return V_bkf_mag_err,longitude_bkf_err,latitude_bkf_err

###########################################################################
